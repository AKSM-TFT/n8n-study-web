---
name: The Study Desk
colors:
  surface: '#fff9ea'
  surface-dim: '#dfdacb'
  surface-bright: '#fff9ea'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f3e4'
  surface-container: '#f3eede'
  surface-container-high: '#ede8d9'
  surface-container-highest: '#e7e2d3'
  on-surface: '#1d1c13'
  on-surface-variant: '#55433b'
  inverse-surface: '#323126'
  inverse-on-surface: '#f6f1e1'
  outline: '#88726a'
  outline-variant: '#dbc1b7'
  surface-tint: '#99461d'
  primary: '#6a2600'
  on-primary: '#ffffff'
  primary-container: '#8a3b12'
  on-primary-container: '#ffb696'
  inverse-primary: '#ffb596'
  secondary: '#635e54'
  on-secondary: '#ffffff'
  secondary-container: '#e9e2d5'
  on-secondary-container: '#69645a'
  tertiary: '#004060'
  on-tertiary: '#ffffff'
  tertiary-container: '#005883'
  on-tertiary-container: '#90cdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb596'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#7a2f06'
  secondary-fixed: '#e9e2d5'
  secondary-fixed-dim: '#cdc6b9'
  on-secondary-fixed: '#1e1b13'
  on-secondary-fixed-variant: '#4a463d'
  tertiary-fixed: '#cbe6ff'
  tertiary-fixed-dim: '#8fcdfe'
  on-tertiary-fixed: '#001e30'
  on-tertiary-fixed-variant: '#004b71'
  background: '#fff9ea'
  on-background: '#1d1c13'
  surface-variant: '#e7e2d3'
typography:
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Source Serif 4
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 2.5rem
  max-width: 1200px
---

## Brand & Style
The design system is built for deep focus, channeling the tactile sensation of a physical desk covered in high-quality stationery. The brand personality is academic, quiet, and intentional, designed to reduce cognitive load for students and researchers.

The aesthetic follows a **Modern Minimalism** approach with a **Flat, Bordered** execution. It rejects digital-first trends like shadows, blurs, or gradients in favor of structural clarity. Visual hierarchy is achieved strictly through line weight, spatial grouping, and high-contrast typography. The emotional response should be one of calm, organized productivity—similar to the feeling of opening a fresh notebook.

## Colors
The palette is rooted in a "warm paper" background to reduce eye strain during long reading sessions. 

- **Primary (Accent):** A burnt sienna used exclusively for functional intent—links, primary actions, and critical focus states. It is never used for decorative elements.
- **Neutral/Surface:** White surfaces provide clear contrast against the parchment-like background for active workspace areas. 
- **Borders:** A consistent 1px stroke in a slightly darker paper tone creates structure without visual clutter.
- **Semantic Colors:** Success, warning, and danger states use muted, earth-toned tints to maintain the organic, non-vibrant feel of the environment.

## Typography
The typography system balances the literary authority of a serif with the functional clarity of a sans-serif.

- **Headlines:** Source Serif 4 is used to evoke the feeling of a printed manuscript. It should be used for all page titles and section headers.
- **Body & UI:** Inter provides a neutral, highly legible experience for reading long-form content and interacting with toolbars.
- **Data & Snippets:** JetBrains Mono is utilized for technical details, metadata, and code, providing a clear visual distinction from the narrative text.

Scale headers down slightly on mobile to ensure line lengths remain comfortable for narrow viewports.

## Layout & Spacing
This design system utilizes a **Fixed Grid** on desktop to maintain a "contained" feel, preventing text lines from becoming too long for comfortable reading. 

- **Grid:** 12-column layout with 24px (1.5rem) gutters.
- **Rhythm:** All spacing (margins, padding) should be multiples of 4px. Use 16px for internal card padding and 32px for section vertical spacing.
- **Adaptive Rules:** On mobile, margins reduce to 16px and the grid collapses to a single column. On tablet, margins are 24px and content uses an 8-column layout.
- **Content-First:** Primary reading panes should never exceed 720px in width to ensure optimal line length (50-75 characters).

## Elevation & Depth
Depth is created through **Tonal Layers** and **1px Outlines**. There are no shadows or blurs in this design system.

- **Level 0 (Base):** The #F7F4EC background.
- **Level 1 (Surface):** White cards or panels sitting on the background, defined by a 1px #E4DFD0 border.
- **Level 2 (Interaction):** Hover states do not lift; instead, they change border color (to the primary accent) or background tint.
- **Modals:** Use a solid 1px border with a slightly thicker weight (2px) or a high-contrast border to separate them from the background, rather than a shadow.

## Shapes
The shape language is conservative and disciplined. 

- **Small Components:** 4px radius for buttons, input fields, and checkboxes to suggest precision and utility.
- **Large Components:** 8px radius for cards and main containers to provide a gentle "paper" feel without looking overly playful.
- **Strictness:** Do not use fully rounded (pill) shapes unless specifically required for small status indicators.

## Components
- **Buttons:**
    - **Primary:** Solid #8A3B12 fill, white text, 4px radius. No gradient.
    - **Secondary:** Transparent fill, 1px #E4DFD0 border, #221F17 text. 
    - **Tertiary:** Text-only, underlined on hover.
- **Cards:** White background, 1px #E4DFD0 border, 8px radius. On hover, the border color shifts to #8A3B12.
- **Input Fields:** 1px #E4DFD0 border, 4px radius, white background. On focus, the border becomes #8A3B12.
- **Status Badges:** Rectangular tags with 2px radius. Use colored text (e.g., Success) on a background with 10% opacity of that same color.
- **Lists:** Separated by 1px horizontal dividers. No zebra-striping.
- **Voice:** UI text must be direct and plain. Avoid all exclamation points. Use sentence case for headings and labels.